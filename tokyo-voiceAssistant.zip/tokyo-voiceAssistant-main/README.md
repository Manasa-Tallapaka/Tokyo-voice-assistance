# tokyo-voiceAssistant

# Project Aim and Objective :- 
The Objective of our project is to create a personal voice assistant using python.This
Assistant currently works online and performs basic tasks like Stream Music,Search
Wikipedia,Open System installed Applications etc..The functionality of the current system
is limited to working online only. The Voice Assistant will gather the audio from the
microphone and then convert that into text. Later, it is sent through GTTS(Google Text To
Speech).GTTS Engine will convert text into audio file in english Language, then that
audio is played using playsound packages of python programming Languages.

# Conclusion of this project :

In this Project, we have discussed a Voice Personal Assistant developed using python.
This assistant currently works online and performs basic tasks like takes the complaint,
takes the attendance, opens the youtube, stream music, search wikipedia, open desktop
applications,care taker information, library information, provides the timings of classes etc.
Through this voice assistant, we have automated various services using a voice input. It is
designed for give responses to the user on the basis of query being asked or the words
spoken by the user such as opening tasks and operations.

The functionality of the current system is limited to working online only. The upcoming
updates of this assistant will have machine learning incorporated in the system which will
result in better suggestions with IOT[x] to control the nearby devices similar to what
Amazon’s Alexa does. This Intelligent Voice Assistant has an enormous and limitless
scope inthe future. Like Siri, Google Now and Cortana most popular personal voice
assistants.

The project will easily able to integrate with devices near future for a Connected Home
using Internet of Things, voice command system and computer vision. The concept of
voice recognition can be applied in different industries as in many situations it will be more
convenient, and save a lot of time and helpful especially for those who have difficulty in
working with manual operations. The primary objective of the program is to provide
services using the voice, and it enables more people who can enjoy this program.
